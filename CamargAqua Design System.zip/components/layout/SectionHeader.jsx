import React from 'react';
export function SectionHeader({ eyebrow, title, lede, dark = false }) {
  return (
    <header style={{ display: 'grid', gridTemplateColumns: '1fr 1.6fr', gap: 48, alignItems: 'end', marginBottom: 40 }}>
      <div>
        {eyebrow}
        <h2 style={{ fontSize: 'clamp(36px,4.4vw,56px)', fontWeight: 300, color: dark ? '#F5F4F0' : 'var(--royal)', marginTop: 14 }}>{title}</h2>
      </div>
      <p style={{ fontFamily: 'var(--sans)', fontSize: 'clamp(16px,1.7vw,21px)', lineHeight: 1.55, color: dark ? 'rgba(245,244,240,0.65)' : 'var(--royal-2)', margin: 0 }}>{lede}</p>
    </header>
  );
}
