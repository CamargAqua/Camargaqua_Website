Flat KPI stat block — big Barlow numeral + small italic unit + muted label.

```jsx
<StatCard value="250" unit="t/an" label="Production visée · Phase 1" tone="pink" />
```

Tones: `soft` (default blush), `pink` (fuchsia-pale), `dark` (navy, for night sections).
