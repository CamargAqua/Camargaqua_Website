Two-column editorial section header used to open nearly every section: big thin display title left, lede paragraph right.

```jsx
<SectionHeader eyebrow={<Eyebrow>Le Produit</Eyebrow>} title={<>Deux formats, <em>une exigence.</em></>} lede="Fraîche ou vivante — choisissez selon votre usage." />
```
