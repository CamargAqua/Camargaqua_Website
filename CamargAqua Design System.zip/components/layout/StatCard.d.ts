/**
 * Flat stat block — big display numeral + unit + short label, used for KPI grids.
 */
export interface StatCardProps {
  value: string | number;
  unit?: string;
  label: string;
  tone?: 'soft' | 'pink' | 'dark';
}
