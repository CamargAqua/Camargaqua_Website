import React from 'react';
export function FeatureCard({ icon, title, description, accent = 'top' }) {
  return (
    <div style={{
      background: 'var(--bg)', borderRadius: 'var(--radius-lg)', padding: '28px 22px',
      borderTop: accent === 'top' ? '3px solid var(--shrimp)' : undefined,
      borderLeft: accent === 'left' ? '3px solid var(--shrimp)' : undefined,
    }}>
      {icon && <div style={{ marginBottom: 16, color: 'var(--shrimp-deep)' }}>{icon}</div>}
      <div style={{ fontSize: 17, fontWeight: 600, color: 'var(--royal)', marginBottom: 6 }}>{title}</div>
      <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6, margin: 0 }}>{description}</p>
    </div>
  );
}
