import React from 'react';

export function TeamCard({ name, role, description, photoSrc, initials }) {
  return (
    <article style={{ position: 'relative', borderRadius: 'var(--radius-xl)', overflow: 'hidden', height: 340, background: 'var(--bg-warm)' }}>
      {photoSrc ? (
        <img src={photoSrc} alt={name} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain', objectPosition: 'center 15%', mixBlendMode: 'multiply' }} />
      ) : (
        <div style={{ width: '100%', height: '100%', display: 'grid', placeItems: 'center', fontFamily: 'var(--serif)', fontSize: 56, color: 'var(--royal)' }}>{initials}</div>
      )}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, padding: '52px 24px 26px',
        background: 'linear-gradient(to top, rgba(15,27,77,0.88) 0%, rgba(15,27,77,0.5) 60%, transparent 100%)',
        display: 'flex', flexDirection: 'column', gap: 4,
      }}>
        <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--shrimp)' }}>{role}</div>
        <h3 style={{ fontFamily: 'var(--serif)', fontSize: 24, fontWeight: 400, margin: 0, color: '#F5F4F0', letterSpacing: '-0.01em' }}>{name}</h3>
        <div style={{ width: 24, height: 1, background: 'var(--shrimp)', margin: '4px 0', opacity: 0.6 }} />
        <p style={{ fontSize: 13, color: 'rgba(245,244,240,0.55)', lineHeight: 1.55, margin: 0 }}>{description}</p>
      </div>
    </article>
  );
}
