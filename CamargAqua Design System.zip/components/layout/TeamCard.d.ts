/**
 * Photo card with a navy gradient caption overlay — used for the founding-team grid.
 */
export interface TeamCardProps {
  name: string;
  role: string;
  description: string;
  /** Photo URL; when omitted, renders initials on a blush field. */
  photoSrc?: string;
  initials?: string;
}
