/**
 * Two-column section header: eyebrow + big display title on the left, lede paragraph on the right.
 */
export interface SectionHeaderProps {
  eyebrow?: React.ReactNode;
  title: React.ReactNode;
  lede: string;
  dark?: boolean;
}
