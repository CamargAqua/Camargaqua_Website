/**
 * Small feature/pillar card with icon, title and description, top- or left-accent border.
 */
export interface FeatureCardProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  accent?: 'top' | 'left';
}
