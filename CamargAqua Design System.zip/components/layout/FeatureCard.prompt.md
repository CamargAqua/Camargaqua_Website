Small pillar/feature card: optional line-icon, bold title, muted description, a colored top or left accent rule.

```jsx
<FeatureCard title="Zéro antibiotique" description="Biosécurité stricte, sans intrant chimique." />
```
