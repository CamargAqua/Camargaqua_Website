Team member card — photo (blend-multiplied onto a blush field to knock out white backgrounds) with a navy gradient caption at the bottom.

```jsx
<TeamCard name="Adrien RIEU" role="Président" description="Stratégie, financement, gouvernance." photoSrc="assets/team/adrien.jpg" />
```

Falls back to two-letter `initials` on a warm-blush field when no photo is supplied.
