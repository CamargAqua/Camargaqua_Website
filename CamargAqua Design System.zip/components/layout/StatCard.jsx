import React from 'react';
export function StatCard({ value, unit, label, tone = 'soft' }) {
  const tones = {
    soft: { background: 'var(--bg-soft)', num: 'var(--royal)' },
    pink: { background: 'var(--shrimp-pale)', num: 'var(--royal)' },
    dark: { background: 'var(--royal-3)', num: '#F5F4F0' },
  };
  const t = tones[tone];
  return (
    <div style={{ background: t.background, borderRadius: 'var(--radius-md)', padding: '32px 24px' }}>
      <div style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(36px,4vw,52px)', lineHeight: 1, color: t.num, fontWeight: 400 }}>
        {value}<span style={{ fontSize: '0.4em', color: 'var(--shrimp-deep)', marginLeft: 4, fontStyle: 'normal' }}>{unit}</span>
      </div>
      <div style={{ fontSize: 13, color: tone === 'dark' ? 'rgba(245,244,240,0.6)' : 'var(--muted)', marginTop: 14 }}>{label}</div>
    </div>
  );
}
