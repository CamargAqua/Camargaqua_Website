Sticky, blurred top navigation bar — the wordmark logo (no icon mark exists), 4 nav links with a 1px fuchsia underline on the active item, and a navy pill CTA.

```jsx
<Topbar active="Le Produit" />
```
