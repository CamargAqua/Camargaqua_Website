/**
 * Fixed, translucent-blur top navigation bar with wordmark, primary nav and CTA.
 */
export interface TopbarProps {
  /** Which nav label is highlighted active. */
  active?: 'Accueil' | 'Le Projet' | 'Le Produit' | 'Notre Ancrage';
}
