import React from 'react';

export function Topbar({ active = 'Accueil' }) {
  const links = ['Accueil', 'Le Projet', 'Le Produit', 'Notre Ancrage'];
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 50, background: 'color-mix(in oklab, var(--bg) 94%, transparent)',
      backdropFilter: 'saturate(140%) blur(12px)', borderBottom: '1px solid color-mix(in oklab, var(--line) 60%, transparent)',
    }}>
      <div style={{ maxWidth: 1680, margin: '0 auto', padding: '0 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 88, gap: 16 }}>
        <a href="#" style={{ fontFamily: 'var(--display)', fontSize: 26, letterSpacing: '0.04em', color: 'var(--royal)', fontWeight: 700, textTransform: 'uppercase' }}>
          Camarg<em style={{ fontStyle: 'italic', color: 'var(--shrimp)', fontWeight: 400, textTransform: 'none' }}>Aqua</em>
        </a>
        <nav style={{ display: 'flex', gap: 36, alignItems: 'center' }}>
          {links.map((l) => (
            <a key={l} href="#" style={{
              fontSize: 15, fontWeight: 600, letterSpacing: '0.02em', padding: '6px 0',
              color: l === active ? 'var(--royal)' : 'var(--muted)',
              borderBottom: l === active ? '1px solid var(--shrimp)' : 'none',
            }}>{l}</a>
          ))}
        </nav>
        <a href="#" style={{
          fontFamily: 'var(--sans)', fontSize: 15, fontWeight: 600, color: 'var(--bg)', background: 'var(--royal)',
          padding: '12px 22px', borderRadius: 'var(--radius-pill)', display: 'inline-flex', alignItems: 'center', gap: 10,
        }}>Nous contacter →</a>
      </div>
    </header>
  );
}
