import React from 'react';

export function FormField({ label, type = 'text', placeholder, textarea = false, options }) {
  const fieldStyle = {
    fontFamily: 'var(--sans)', fontSize: 15, color: 'var(--royal)', background: 'var(--bg)',
    border: '1px solid transparent', borderRadius: 'var(--radius-sm)', padding: '12px 14px', width: '100%',
  };
  return (
    <div style={{ display: 'grid', gap: 6 }}>
      <label style={{ fontSize: 12, color: 'var(--shrimp-deep)', fontWeight: 500 }}>{label}</label>
      {textarea ? (
        <textarea placeholder={placeholder} style={{ ...fieldStyle, minHeight: 110, resize: 'vertical' }} />
      ) : options ? (
        <select style={fieldStyle}>{options.map((o) => <option key={o}>{o}</option>)}</select>
      ) : (
        <input type={type} placeholder={placeholder} style={fieldStyle} />
      )}
    </div>
  );
}
