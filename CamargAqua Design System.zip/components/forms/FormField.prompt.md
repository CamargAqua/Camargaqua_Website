Labeled form field for contact/lead forms — fuchsia-labeled, blush fill, focuses to a fuchsia border.

```jsx
<FormField label="Email" type="email" placeholder="vous@exemple.fr" />
<FormField label="Message" textarea placeholder="Votre message" />
<FormField label="Sujet" options={['Direction', 'Commercial', 'Presse', 'Partenariat', 'Autre']} />
```
