/**
 * Labeled text input / textarea / select, matching the contact-page form.
 */
export interface FormFieldProps {
  label: string;
  type?: 'text' | 'email' | 'tel';
  placeholder?: string;
  /** Render as a <textarea> instead of <input>. */
  textarea?: boolean;
  /** Render as a <select> with these options instead of an input. */
  options?: string[];
}
