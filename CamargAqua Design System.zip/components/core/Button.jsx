import React from 'react';

export function Button({ children, variant = 'primary', href, onClick, type = 'button', arrow = true }) {
  const base = {
    fontFamily: 'var(--sans)', fontSize: 14, letterSpacing: '0.01em', fontWeight: 500,
    padding: '16px 28px', display: 'inline-flex', alignItems: 'center', gap: 12,
    borderRadius: 'var(--radius-pill)', cursor: 'pointer', textDecoration: 'none',
    border: '1px solid transparent', transition: 'all .25s ease',
  };
  const variants = {
    primary: { background: 'var(--shrimp)', color: 'var(--bg)', borderColor: 'var(--shrimp)' },
    outline: { background: 'transparent', color: 'var(--royal)', borderColor: 'var(--royal)' },
    'ghost-light': { background: 'transparent', color: 'var(--bg)', borderColor: 'rgba(245,244,240,0.4)' },
  };
  const style = { ...base, ...variants[variant] };
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} onClick={onClick} type={href ? undefined : type} style={style}>
      {children}{arrow && <span aria-hidden="true">→</span>}
    </Tag>
  );
}
