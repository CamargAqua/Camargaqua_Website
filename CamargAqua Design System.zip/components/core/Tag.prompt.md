Small taxonomy chips, section eyebrows, and the "— chapter" label rhythm used to open every section.

```jsx
<Tag variant="royal">Vivante · Premium</Tag>
<Eyebrow>Le Produit</Eyebrow>
<ChapterLabel dark>L'opportunité de marché</ChapterLabel>
```

`Tag` variants: `pale` (default, fuchsia-tinted), `royal` (navy fill for dark badges over photos), `outline`. `ChapterLabel` should open nearly every content section — pass `dark` when the section background is `--royal-3`.
