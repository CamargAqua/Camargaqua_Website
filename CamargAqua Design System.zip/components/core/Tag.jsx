import React from 'react';

export function Tag({ children, variant = 'pale' }) {
  const variants = {
    pale: { background: 'var(--shrimp-pale)', color: 'var(--shrimp-deep)' },
    royal: { background: 'var(--royal)', color: 'var(--bg)' },
    outline: { background: 'transparent', color: 'var(--royal)', border: '1px solid var(--line)' },
  };
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px',
      borderRadius: 'var(--radius-pill)', fontFamily: 'var(--sans)', fontSize: 12,
      letterSpacing: '0.02em', fontWeight: 500, ...variants[variant],
    }}>{children}</span>
  );
}

export function Eyebrow({ children, rule = true }) {
  return (
    <div style={{
      fontFamily: 'var(--sans)', fontSize: 12, letterSpacing: '0.04em', color: 'var(--shrimp-deep)',
      fontWeight: 500, display: 'inline-flex', alignItems: 'center', gap: 10,
    }}>
      {rule && <span style={{ width: 18, height: 1, background: 'var(--shrimp)' }} />}
      {children}
    </div>
  );
}

export function ChapterLabel({ children, dark = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14, borderTop: `2px solid ${dark ? 'rgba(232,180,166,0.25)' : 'var(--shrimp-pale)'}`,
      paddingTop: 28, marginBottom: 40,
    }}>
      <span style={{ fontFamily: 'var(--serif)', fontSize: 13, color: 'var(--shrimp-deep)', opacity: 0.8 }}>—</span>
      <span style={{
        fontFamily: 'var(--sans)', fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase',
        fontWeight: 500, color: dark ? 'rgba(250,233,226,0.45)' : 'var(--muted)',
      }}>{children}</span>
    </div>
  );
}
