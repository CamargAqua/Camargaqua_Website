/**
 * Small pill label used for taxonomy/status chips (e.g. "Format 1", "Vivante · Premium").
 */
export interface TagProps {
  children: React.ReactNode;
  variant?: 'pale' | 'royal' | 'outline';
}

/** Small uppercase-tracked label with a leading rule, used above section headlines. */
export interface EyebrowProps {
  children: React.ReactNode;
  /** Show the leading 18px horizontal rule. Default true. */
  rule?: boolean;
}

/** "— CHAPTER TITLE" divider that opens every content section on the site. */
export interface ChapterLabelProps {
  children: React.ReactNode;
  /** Use the light-on-navy palette for dark section backgrounds. Default false. */
  dark?: boolean;
}
