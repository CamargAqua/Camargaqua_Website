Pill CTA button used for all primary/secondary actions across the site.

```jsx
<Button variant="primary" href="projet.html">Découvrir le projet</Button>
<Button variant="outline">En savoir plus</Button>
<Button variant="ghost-light" arrow={false}>Voir plus</Button>
```

Variants: `primary` (fuchsia fill, main CTA — one per section max), `outline` (royal-navy border, transparent fill, hovers to filled navy), `ghost-light` (light border/text, for use over dark photography or navy sections). All variants show a trailing → arrow by default; pass `arrow={false}` to omit.
