/**
 * Pill-shaped call-to-action button — primary (fuchsia fill), outline (royal-navy border) or ghost-light (for use on photo/dark backgrounds).
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Visual style. Default 'primary'. */
  variant?: 'primary' | 'outline' | 'ghost-light';
  /** Renders as <a> when provided, else <button>. */
  href?: string;
  onClick?: () => void;
  type?: 'button' | 'submit';
  /** Trailing arrow glyph. Default true. */
  arrow?: boolean;
}
