const { Eyebrow, ChapterLabel, StatCard, FeatureCard, SectionHeader, TeamCard, Button, Tag } = window.CamargAquaDesignSystem_df8897;
const { Wrap } = window.Shared;

function HomePage({ nav }) {
  return (<>
    <section style={{ position: 'relative', minHeight: 560, display: 'flex', alignItems: 'flex-end', padding: '0 0 56px' }}>
      <div style={{ position: 'absolute', inset: 0, zIndex: -1 }}><image-slot id="home-hero" placeholder="Flamants roses / marais de Camargue"></image-slot></div>
      <div style={{ position: 'absolute', inset: 0, zIndex: 0, background: 'linear-gradient(105deg, rgba(250,233,226,0.92) 0%, rgba(250,233,226,0.76) 38%, rgba(250,233,226,0.28) 68%, transparent 100%)', pointerEvents: 'none' }}></div>
      <Wrap style={{ position: 'relative', zIndex: 1 }}>
        <Eyebrow>Camargue · Méditerranée · France</Eyebrow>
        <h1 style={{ fontSize: 'clamp(52px,6.6vw,96px)', fontWeight: 300, lineHeight: 1.02, marginTop: 24, maxWidth: '18ch' }}>L'aquaculture française <em style={{ fontStyle: 'italic', color: 'var(--shrimp)', fontFamily: 'var(--display)' }}>réinventée.</em></h1>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 'clamp(20px,2vw,26px)', color: 'var(--royal-2)', marginTop: 20, maxWidth: '44ch' }}>La première crevette 100% française, élevée en eau de mer directe, au cœur de la Camargue.</p>
        <div style={{ marginTop: 28 }}><Button variant="primary" onClick={() => nav('projet')}>Découvrir le projet</Button></div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 24 }}>
          <span style={{ fontFamily: 'var(--serif)', fontSize: 64, fontWeight: 300, color: 'var(--royal)' }}>250</span>
          <span style={{ fontFamily: 'var(--serif)', fontStyle: 'italic', fontSize: 22, color: 'var(--shrimp-deep)' }}>t/an</span>
          <span style={{ color: 'var(--shrimp)', margin: '0 4px' }}>—</span>
          <span style={{ fontSize: 14, color: 'var(--muted)' }}>Production visée · Phase 1 · Foncier acquis</span>
        </div>
      </Wrap>
    </section>

    <section style={{ padding: '48px 0' }}>
      <Wrap>
        <div style={{ textAlign: 'left', maxWidth: 720 }}>
          <Eyebrow rule={false}>Le terroir</Eyebrow>
          <p style={{ fontFamily: 'var(--serif)', fontSize: 'clamp(36px,5vw,60px)', fontWeight: 300, color: 'var(--royal)', lineHeight: 1.1, marginTop: 16 }}>La Camargue n'est pas une adresse.<br /><em style={{ color: 'var(--shrimp-deep)', fontStyle: 'normal' }}>C'est un terroir.</em></p>
          <p style={{ marginTop: 20, fontSize: 17, color: 'var(--muted)', lineHeight: 1.7 }}>Réserve de biosphère UNESCO. Eau de mer méditerranéenne accessible en direct. Delta du Rhône.</p>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 32 }}>
          {['Réserve de biosphère UNESCO', 'Eau de mer directe · Méditerranée', 'Delta du Rhône · Port-Saint-Louis', 'Foncier acquis · Projet ancré'].map((t) => <Tag key={t} variant="outline">{t}</Tag>)}
        </div>
      </Wrap>
    </section>

    <section style={{ background: 'var(--royal-3)', color: 'rgba(245,244,240,0.9)', padding: '72px 0' }}>
      <Wrap>
        <ChapterLabel dark>L'opportunité de marché</ChapterLabel>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          <StatCard value="+6" unit="%" label="Croissance annuelle" tone="dark" />
          <StatCard value="120 000" unit="t" label="Consommation France / an" tone="dark" />
          <StatCard value="12 000" unit="km" label="Trajet moyen import" tone="dark" />
        </div>
      </Wrap>
    </section>

    <section style={{ background: 'var(--bg-soft)', padding: '56px 0' }}>
      <Wrap>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' }}>
          <div style={{ aspectRatio: '4/3', borderRadius: 8, overflow: 'hidden' }}><image-slot id="home-product" placeholder="Crevette fraîche CamargAqua"></image-slot></div>
          <div>
            <Eyebrow>Le produit</Eyebrow>
            <h2 style={{ fontSize: 'clamp(32px,4vw,48px)', fontWeight: 300, marginTop: 14 }}>Une crevette <em style={{ color: 'var(--shrimp-deep)', fontStyle: 'italic' }}>élevée en eau de mer.</em></h2>
            <p style={{ fontSize: 15, color: 'var(--royal-2)', lineHeight: 1.65, marginTop: 14 }}>Chair ferme, goût franc, fraîcheur d'une régularité absolue.</p>
            <div style={{ marginTop: 20 }}><Button variant="primary" onClick={() => nav('produit')}>Découvrir le produit</Button></div>
          </div>
        </div>
      </Wrap>
    </section>

    <section style={{ padding: '64px 0' }}>
      <Wrap>
        <ChapterLabel>L'équipe</ChapterLabel>
        <SectionHeader eyebrow={null} title={<>Les porteurs<br /><em style={{ fontStyle: 'italic', color: 'var(--shrimp)' }}>du projet.</em></>} lede="Une équipe pluridisciplinaire — direction, technique aquacole, opérations terrain." />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 24 }}>
          <TeamCard name="Adrien RIEU" role="Président" description="Stratégie, financement, gouvernance." photoSrc="../../assets/team/adrien.jpg" />
          <TeamCard name="Georges HETZEL" role="Directeur Technique" description="Ingénierie aquacole, RAS, biologie de la crevette." photoSrc="../../assets/team/georges.jpg" />
          <TeamCard name="Victor MICHEL" role="Directeur Opérationnel" description="Opérations site, partenariats, déploiement industriel." photoSrc="../../assets/team/victor.jpg" />
        </div>
      </Wrap>
    </section>
  </>);
}
window.HomePage = HomePage;
