const { Eyebrow, ChapterLabel, StatCard, FeatureCard, Button } = window.CamargAquaDesignSystem_df8897;
const { Wrap, PageHero } = window.Shared;

function ProjetPage({ nav }) {
  return (<>
    <section style={{ position: 'relative', minHeight: 380, display: 'flex', alignItems: 'flex-end', padding: '64px 0 48px' }}>
      <div style={{ position: 'absolute', inset: 0, zIndex: -1 }}><image-slot id="projet-hero" placeholder="Vue aérienne Port-Saint-Louis-du-Rhône"></image-slot></div>
      <div style={{ position: 'absolute', inset: 0, zIndex: 0, background: 'linear-gradient(105deg, rgba(250,233,226,0.93) 0%, rgba(250,233,226,0.82) 42%, rgba(250,233,226,0.42) 68%, rgba(15,27,77,0.15) 100%)', pointerEvents: 'none' }}></div>
      <Wrap style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}><a onClick={() => nav('home')} style={{ color: 'var(--muted)' }}>Accueil</a> <span style={{ color: 'var(--shrimp)', margin: '0 10px' }}>/</span> Le Projet</div>
        <Eyebrow>Le Projet</Eyebrow>
        <h1 style={{ fontSize: 'clamp(40px,5.5vw,72px)', fontWeight: 300, marginTop: 18, maxWidth: '24ch' }}>La maîtrise <em style={{ fontStyle: 'italic', color: 'var(--shrimp)' }}>comme méthode.</em></h1>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 'clamp(17px,1.8vw,22px)', color: 'var(--royal-2)', marginTop: 20 }}>Une unité d'aquaculture de précision en Camargue, parmi les plus avancées d'Europe.</p>
      </Wrap>
    </section>

    <section style={{ padding: '48px 0' }}>
      <Wrap>
        <ChapterLabel>Implantation &amp; Infrastructure</ChapterLabel>
        <div style={{ display: 'grid', gridTemplateColumns: '1.15fr 1fr', gap: 16 }}>
          <div style={{ borderRadius: 10, overflow: 'hidden', minHeight: 340 }}><img src="../../assets/renders/render-1.jpeg" alt="Vue 3D bâtiment CamargAqua" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ borderRadius: 10, overflow: 'hidden', flex: 1, minHeight: 180 }}><img src="../../assets/renders/render-2.jpeg" alt="Intérieur bassins CamargAqua" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /></div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <StatCard value="Acquis" label="Foncier · sécurisé, titré" tone="dark" />
              <StatCard value="Directe" label="Eau de mer · Méditerranée" tone="soft" />
              <StatCard value="250" unit="t/an" label="Production · Phase 1" tone="soft" />
              <StatCard value="Camargue" label="Région · Réserve UNESCO" tone="dark" />
            </div>
          </div>
        </div>
      </Wrap>
    </section>

    <section style={{ background: 'var(--bg-soft)', padding: '64px 0' }}>
      <Wrap>
        <ChapterLabel>Technologie RAS</ChapterLabel>
        <h2 style={{ fontSize: 'clamp(32px,4vw,52px)', fontWeight: 300, marginBottom: 32 }}>Circuit fermé, <em style={{ fontStyle: 'italic', color: 'var(--shrimp-deep)' }}>contrôle total.</em></h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14 }}>
          <FeatureCard title="Eau recyclée à 95%" description="Filtrée en continu, sans rejet en milieu naturel." />
          <FeatureCard title="Zéro antibiotique" description="Biosécurité stricte, sans intrant chimique." />
          <FeatureCard title="365 jours / an" description="Production régulière, indépendante des saisons." />
          <FeatureCard title="Traçabilité totale" description="Lot unitaire, de l'écloserie au client final." />
        </div>
      </Wrap>
    </section>

    <section style={{ padding: '48px 0' }}>
      <Wrap>
        <div style={{ background: 'var(--shrimp)', borderRadius: 6, padding: 56, display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 32, alignItems: 'end' }}>
          <h2 style={{ color: 'var(--royal)', fontSize: 'clamp(32px,4vw,48px)', fontWeight: 300 }}>Un produit qui découle de cette <em style={{ fontStyle: 'italic', color: 'var(--royal-3)' }}>maîtrise.</em></h2>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}><Button variant="outline" onClick={() => nav('produit')}>Le produit</Button></div>
        </div>
      </Wrap>
    </section>
  </>);
}
window.ProjetPage = ProjetPage;
