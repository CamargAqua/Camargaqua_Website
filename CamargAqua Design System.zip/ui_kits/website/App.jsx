const { Topbar } = window.CamargAquaDesignSystem_df8897;
const { Footer } = window.Shared;

function App() {
  const [page, setPage] = React.useState('home');
  const pages = { home: window.HomePage, projet: window.ProjetPage, produit: window.ProduitPage, contact: window.ContactPage };
  const Page = pages[page];
  const navLabels = { home: 'Accueil', projet: 'Le Projet', produit: 'Le Produit', contact: 'Notre Ancrage' };
  return (
    <div style={{ background: 'var(--bg)' }}>
      <div style={{ position: 'sticky', top: 0, zIndex: 50 }}>
        <Topbar active={navLabels[page]} />
      </div>
      <nav style={{ display: 'flex', gap: 8, justifyContent: 'center', padding: '10px 0', background: 'var(--bg-soft)', fontSize: 13 }}>
        {Object.keys(pages).map((k) => (
          <button key={k} onClick={() => setPage(k)} style={{ border: 'none', background: page === k ? 'var(--shrimp)' : 'transparent', color: page === k ? '#fff' : 'var(--royal)', padding: '6px 14px', borderRadius: 999, cursor: 'pointer', fontFamily: 'var(--sans)', fontWeight: 500 }}>{navLabels[k]}</button>
        ))}
      </nav>
      <Page nav={setPage} />
      <Footer />
    </div>
  );
}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
