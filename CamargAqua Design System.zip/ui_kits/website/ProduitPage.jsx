const { Eyebrow, ChapterLabel, Tag, Button } = window.CamargAquaDesignSystem_df8897;
const { Wrap } = window.Shared;

function ProduitPage({ nav }) {
  return (<>
    <section style={{ position: 'relative', minHeight: 380, display: 'flex', alignItems: 'flex-end', padding: '64px 0 48px' }}>
      <div style={{ position: 'absolute', inset: 0, zIndex: -1 }}><image-slot id="produit-hero" placeholder="Crevette élevée en Camargue"></image-slot></div>
      <div style={{ position: 'absolute', inset: 0, zIndex: 0, background: 'linear-gradient(105deg, rgba(250,233,226,0.93) 0%, rgba(250,233,226,0.82) 42%, rgba(250,233,226,0.42) 68%, rgba(15,27,77,0.15) 100%)', pointerEvents: 'none' }}></div>
      <Wrap style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}><a onClick={() => nav('home')} style={{ color: 'var(--muted)' }}>Accueil</a> <span style={{ color: 'var(--shrimp)', margin: '0 10px' }}>/</span> Le Produit</div>
        <Eyebrow>Le Produit</Eyebrow>
        <h1 style={{ fontSize: 'clamp(40px,5.5vw,72px)', fontWeight: 300, marginTop: 18 }}>Une crevette <em style={{ fontStyle: 'italic', color: 'var(--shrimp)' }}>d'une fraîcheur rare.</em></h1>
      </Wrap>
    </section>

    <section style={{ padding: '48px 0' }}>
      <Wrap>
        <ChapterLabel>Nos produits</ChapterLabel>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {[['Fraîche', 'Crevette Fraîche', '20/30 · 30/40 unités/kg', 'Caisse 5 kg, glacée'], ['Vivante · Premium', 'Crevette Vivante', '15/20 · 20/30 unités/kg', 'Transport oxygéné, eau de mer']].map(([badge, name, calibre, cond]) => (
            <div key={name} style={{ borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ position: 'relative', height: 260 }}>
                <image-slot id={`produit-${name}`} placeholder={name}></image-slot>
                <span style={{ position: 'absolute', top: 16, left: 16, background: badge.includes('Premium') ? 'var(--royal)' : 'var(--shrimp)', color: badge.includes('Premium') ? '#fff' : 'var(--royal)', padding: '6px 14px', borderRadius: 999, fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.1em', zIndex: 2 }}>{badge}</span>
              </div>
              <div style={{ padding: '20px 24px', background: 'var(--bg)', borderTop: '2px solid var(--shrimp-pale)' }}>
                <h3 style={{ fontSize: 22, fontWeight: 400, color: 'var(--royal)', marginBottom: 12 }}>{name}</h3>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '8px 0', borderBottom: '1px solid var(--line)' }}><span style={{ color: 'var(--muted)' }}>Calibre</span><span style={{ color: 'var(--royal)', fontWeight: 500 }}>{calibre}</span></div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '8px 0' }}><span style={{ color: 'var(--muted)' }}>Conditionnement</span><span style={{ color: 'var(--royal)', fontWeight: 500 }}>{cond}</span></div>
              </div>
            </div>
          ))}
        </div>
      </Wrap>
    </section>

    <section style={{ background: 'var(--bg-soft)', padding: '56px 0' }}>
      <Wrap>
        <ChapterLabel>Le processus</ChapterLabel>
        <h2 style={{ fontSize: 'clamp(32px,4vw,48px)', fontWeight: 300, marginBottom: 28 }}>De l'œuf à la crevette <em style={{ fontStyle: 'italic', color: 'var(--shrimp-deep)' }}>premium.</em></h2>
        {['Sélection des larves', 'Nurserie', 'Grossissement en eau de mer', 'Récolte & conditionnement'].map((step, i) => (
          <div key={step} style={{ display: 'grid', gridTemplateColumns: '48px 1fr', gap: 20, padding: '18px 0', borderBottom: i < 3 ? '1px solid var(--line)' : 'none' }}>
            <div style={{ fontFamily: 'var(--serif)', fontSize: 32, fontWeight: 300, color: 'var(--shrimp-pale)' }}>0{i + 1}</div>
            <div><h4 style={{ fontSize: 17, fontWeight: 600, color: 'var(--royal)', marginBottom: 4 }}>{step}</h4></div>
          </div>
        ))}
      </Wrap>
    </section>

    <section style={{ padding: '48px 0', textAlign: 'center' }}>
      <Button variant="primary" onClick={() => nav('contact')}>Nous contacter</Button>
    </section>
  </>);
}
window.ProduitPage = ProduitPage;
