const { Eyebrow, Button, FormField } = window.CamargAquaDesignSystem_df8897;
const { Wrap } = window.Shared;

function ContactPage({ nav }) {
  const [sent, setSent] = React.useState(false);
  return (
    <section style={{ padding: '72px 0', minHeight: 500 }}>
      <Wrap style={{ maxWidth: 720 }}>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}><a onClick={() => nav('home')} style={{ color: 'var(--muted)' }}>Accueil</a> <span style={{ color: 'var(--shrimp)', margin: '0 10px' }}>/</span> Contact</div>
        <Eyebrow>Contact</Eyebrow>
        <h1 style={{ fontSize: 'clamp(36px,4.5vw,56px)', fontWeight: 300, marginTop: 18, marginBottom: 32 }}>Parlons de <em style={{ fontStyle: 'italic', color: 'var(--shrimp)' }}>votre projet.</em></h1>
        {sent ? (
          <div style={{ background: 'var(--shrimp-pale)', color: 'var(--shrimp-deep)', padding: '14px 16px', borderRadius: 6, fontSize: 14 }}>Message envoyé — merci, nous revenons vers vous rapidement.</div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: 'grid', gap: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
              <FormField label="Nom" placeholder="Votre nom" />
              <FormField label="Email" type="email" placeholder="vous@exemple.fr" />
            </div>
            <FormField label="Sujet" options={['Direction', 'Commercial', 'Presse', 'Partenariat', 'Autre']} />
            <FormField label="Message" textarea placeholder="Votre message" />
            <div><Button variant="primary" type="submit">Envoyer</Button></div>
          </form>
        )}
      </Wrap>
    </section>
  );
}
window.ContactPage = ContactPage;
