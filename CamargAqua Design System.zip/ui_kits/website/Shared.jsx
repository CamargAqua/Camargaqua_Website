const { Topbar, Eyebrow, ChapterLabel, StatCard, FeatureCard, SectionHeader, TeamCard, Button, Tag } = window.CamargAquaDesignSystem_df8897;

function Wrap({ children, style }) { return <div style={{ maxWidth: 1680, margin: '0 auto', padding: '0 32px', ...style }}>{children}</div>; }

function Footer() {
  return (
    <footer style={{ background: 'var(--royal-3)', color: 'rgba(245,244,240,0.7)', padding: '56px 0 28px' }}>
      <Wrap>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 32, paddingBottom: 32, borderBottom: '1px solid rgba(245,244,240,0.12)' }}>
          <div>
            <div style={{ fontFamily: 'var(--display)', fontSize: 22, color: '#F5F4F0', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Camarg<em style={{ fontStyle: 'italic', color: 'var(--shrimp)', fontWeight: 400 }}>Aqua</em></div>
            <div style={{ fontFamily: 'var(--serif)', fontSize: 16, color: 'rgba(245,244,240,0.8)', maxWidth: '30ch', marginTop: 16, lineHeight: 1.5 }}>Une aquaculture française, ancrée en <em style={{ color: 'var(--shrimp)' }}>Camargue.</em></div>
          </div>
          {[['Navigation', ['Accueil', 'Le Projet', 'Le Produit', 'Contact']], ['Société', ['Mentions légales', 'Confidentialité']], ['Suivre', ['LinkedIn', 'Presse']]].map(([h, items]) => (
            <div key={h}>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--shrimp)', marginBottom: 16 }}>{h}</div>
              <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'grid', gap: 8 }}>{items.map((i) => <li key={i} style={{ fontSize: 13, color: 'rgba(245,244,240,0.8)' }}>{i}</li>)}</ul>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 24, fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(245,244,240,0.4)' }}>
          <span>© 2026 CamargAqua SAS</span><span>Port-Saint-Louis-du-Rhône · France</span>
        </div>
      </Wrap>
    </footer>
  );
}

function PageHero({ eyebrow, title, lede, image }) {
  return (
    <section style={{
      position: 'relative', padding: '64px 0 48px',
      backgroundImage: `linear-gradient(105deg, rgba(250,233,226,0.93) 0%, rgba(250,233,226,0.82) 42%, rgba(250,233,226,0.42) 68%, rgba(15,27,77,0.15) 100%), url(${image})`,
      backgroundSize: 'cover', backgroundPosition: 'center 45%', minHeight: 380,
    }}>
      <Wrap>
        <Eyebrow>{eyebrow}</Eyebrow>
        <h1 style={{ fontSize: 'clamp(40px,5.5vw,72px)', fontWeight: 300, marginTop: 18, maxWidth: '24ch' }}>{title}</h1>
        <p style={{ fontFamily: 'var(--sans)', fontSize: 'clamp(17px,1.8vw,22px)', color: 'var(--royal-2)', marginTop: 20, maxWidth: '55ch' }}>{lede}</p>
      </Wrap>
    </section>
  );
}

window.Shared = { Wrap, Footer, PageHero };
