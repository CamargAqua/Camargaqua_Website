# CamargAqua Design System

CamargAqua is a French aquaculture startup building the country's first industrial-scale shrimp farm, in Port-Saint-Louis-du-Rhône (Camargue delta, Bouches-du-Rhône). France imports 95% of the shrimp it eats; CamargAqua is building a RAS (recirculating aquaculture system) facility that farms *Litopenaeus vannamei* in direct-fed Mediterranean seawater, targeting 250 t/year in Phase 1 — sold fresh, never frozen, delivered same-day (J+0/J+1) versus the ~21-day frozen import chain.

Key facts pulled from the site: land acquired at Port-Saint-Louis-du-Rhône (Rhône/Mediterranean/industrial-zone confluence); closed-loop RAS with ~95% water recycled, zero discharge, no antibiotics, 365-day production; unit-level traceability; three-person founding team (Adrien Rieu — President/strategy & finance, Georges Hetzel — Technical Director/RAS & shrimp biology, Victor Michel — Operations Director/site & industrial deployment); currently raising a seed round.

There is a single product/surface today: the **marketing & investor website** (camargaqua.fr) — a static HTML/CSS/JS site with 5 pages (Accueil, Le Projet, Le Produit, Notre Ancrage, Contact) built to attract investors, partners and future B2B buyers (restaurants, distributors).

## Sources

- Company website: https://camargaqua.com/ (canonical https://camargaqua.fr/)
- GitHub repo: [CamargAqua/Camargaqua_Website](https://github.com/CamargAqua/Camargaqua_Website) — the full static site source (HTML pages, `assets/site.css` token file, team photos, 3D renders). Explore this repo further for the complete page markup, the contact-form logic (`assets/site.js`), and legal pages.

No Figma file or component library was attached — this design system was built by reading the shipped site code directly (ground truth), not screenshots.

## Components

- `components/core/Button.jsx` — pill CTA button (primary / outline / ghost-light)
- `components/core/Tag.jsx` — `Tag`, `Eyebrow`, `ChapterLabel` (pill chips + section-opening labels)
- `components/forms/FormField.jsx` — labeled input / textarea / select
- `components/layout/StatCard.jsx` — KPI stat block
- `components/layout/FeatureCard.jsx` — icon feature/pillar card
- `components/layout/SectionHeader.jsx` — two-column editorial section heading
- `components/layout/TeamCard.jsx` — team member photo card with gradient overlay
- `components/navigation/Topbar.jsx` — fixed blurred navigation bar

## Index

- `styles.css` — root stylesheet, imports everything below
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`, `base.css`
- `assets/` — favicon, team photos, 3D renders (see ICONOGRAPHY below — no logo exists yet)
- `components/` — reusable UI primitives (`core/` buttons, tags, form fields; `layout/` cards & section chrome; `navigation/` topbar)
- `ui_kits/website/` — click-through recreation of the marketing site (home, project, product, contact)
- `guidelines/` — foundation specimen cards (Design System tab)
- `SKILL.md` — portable skill definition for use in Claude Code

## Content fundamentals

- **Language & voice**: All copy is in French, written for two audiences at once — investors/partners and future B2B/retail buyers. Tone is confident, declarative, short sentences, no hedging. Headlines read like manifesto lines: *"La Camargue n'est pas une adresse. C'est un terroir."* / *"La maîtrise comme méthode."* / *"Pas juste s'implanter. S'engager."*
- **Address**: impersonal/institutional — no "tu/vous" direct address in headlines; body copy occasionally addresses the reader directly in CTAs ("Nous contacter").
- **Numbers as heroes**: big stats are dropped in as standalone display-type figures with a small italic unit (250 t/an, 6 h, 21 j, 12 000 km, 95%) — copy leans on contrast pairs (CamargAqua vs. imported) rather than long explanation.
- **Emphasis pattern**: one key phrase per sentence is set in italic Barlow Condensed and colored fuchsia (`.it` / `<em>`) — e.g. "élevée en eau de mer *directe*". Never bold+italic together; bold (`<strong>`) is reserved for the single hardest fact in a paragraph.
- **No emoji.** Iconography instead uses small checkmark/circle/arrow glyphs (✓ ⟳ ◦) for status lists, and thin-stroke line icons for feature call-outs.
- **Structure**: every section opens with a small "chapter label" (— + uppercase eyebrow in mono-ish tracking) before the headline — a print-magazine rhythm, not a typical SaaS scroll.
- **Vibe**: terroir / craft / precision-engineering, not "tech startup." Language borrows from wine/agriculture ("terroir", "cru") to root an industrial RAS facility in a place, deliberately positioning against anonymous frozen imports.

## Visual foundations

- **Palette**: a blush/rose neutral field (`--bg #FAF0F4`, `--bg-soft #F3E0EA`) carries almost every section — CamargAqua uses warm pink as a *neutral*, not an accent. The accent is a single saturated fuchsia (`--shrimp #D6007A`) used sparingly for CTAs, numerals, underlines and small tags. A deep navy (`--royal #1B2A6B`, `--royal-3 #0F1B4D`) is the ink color and doubles as a dark "night" surface for contrast sections (footer, market-opportunity stats, RAS params). No gradients as backgrounds except a very light directional wash behind hero photography — never decorative gradients on cards or buttons.
- **Type**: Barlow Condensed (display: condensed grotesque, weight 300 for big editorial headlines, 600/700 for labels/nav) paired with DM Sans (body, weight 400/500). Big H2s run astonishingly large (`clamp(44px,5.8vw,88px)`) at font-weight 300 — thin display type is a signature move, not thin-as-weak. JetBrains Mono appears only for tiny uppercase micro-labels (footer column headers, chapter tags) at ~10-11px with heavy letter-spacing.
- **Spacing**: generous, airy — sections pad `clamp(36px,5vw,72px)` vertically; a max content width of 1680px with a fluid gutter (`max(20px,4vw)`). Grids are simple (2, 3 or 4 even columns) with 16-24px gaps; nothing denser.
- **Backgrounds**: full-bleed photography is central (hero shots of Camargue marshes, shrimp, flamingos) always under a soft blush-to-transparent diagonal gradient overlay so headline text stays legible — never a flat scrim. No hand-drawn illustration, no repeating patterns/textures. Full-bleed real photography + two solid "night" (navy) section backgrounds for contrast are the only two background modes.
- **Animation**: subtle and slow. Scroll-triggered reveal-on-view (fade + 28px rise, `cubic-bezier(0.16,1,0.3,1)`, ~0.75s, staggered 80ms per item). Hero background photography has a barely-perceptible 14-16s ambient brightness/saturation "shimmer" loop (evokes water). No bounces, no spring physics, no page-transition flourish.
- **Hover states**: cards lift 2-4px with a soft navy-tinted shadow and/or shift background one shade warmer (bg-soft → shrimp-pale); links get color shift to `--shrimp-deep` plus widening letter-spacing or growing gap before an arrow glyph; primary buttons darken to `--shrimp-deep`. No underline reveals except the active nav-item's 1px rule.
- **Press/active states**: not distinctly styled beyond the hover treatment (no visible :active shrink) — this is a marketing site, not an app with tactile feedback needs.
- **Borders**: hairline (1px) `--line` (a rose-fuchsia, not gray) dividers between sections and list rows; cards mostly borderless with a colored 2-3px top or left accent border instead of a full outline.
- **Corner radii**: small and consistent — 6-8px for cards and images, up to 10-12px for feature cards/team cards, and full pill (999px) exclusively for buttons and tag chips. Never sharp corners on cards, never fully squared buttons.
- **Shadows**: soft, warm-tinted (navy or fuchsia at low opacity), used only on hover-lift, never resting — resting cards are flat, differentiated by fill color alone.
- **Transparency/blur**: `backdrop-filter: blur()` + translucent blush fill is the go-to for anything overlaid on a photo (fixed topbar, hero stat callouts, map badges) — glassmorphism used purposefully for legibility over imagery, not decoratively elsewhere.
- **Imagery color vibe**: warm, sunlit, naturalistic color grading (current placeholders are Unsplash marsh/shrimp/flamingo photography) — no black & white, no heavy grain, no cool/blue color grade except the navy night sections which are solid color, not imagery.
- **Cards**: flat fill (bg-soft, shrimp-pale, or navy-dark for contrast cards), no border, 6-10px radius, a top or left 2-4px accent-color rule, generous internal padding (24-44px), hover = lift + shadow + warmer fill.
- **Layout rules**: sticky/fixed translucent-blur topbar at all times; content sections are full-width bands with an inner `.wrap` max-width container; no sidebars, no sticky secondary nav — a single continuous vertical scroll per page.

## Iconography

- **System**: hand-picked thin-stroke (1.5-2px) line icons, inline SVG, `stroke="currentColor"`, no fill — matches a Feather/Lucide-style outline system but is drawn ad hoc per icon rather than pulled from a library. No icon font.
- **Usage**: icons appear small (28-40px) inside feature cards/pillars (droplet, shield/no-antibiotic, clock, checkmark-circle for traceability) and inside "terroir pill" chips.
- **Status glyphs**: plain text/unicode ✓ (done), ⟳ (in progress), ◦ (upcoming), and a small colored dot (`●`) as a separator in the footer — not full icon treatments.
- **Emoji**: never used.
- **No icon set/sprite existed in the codebase to copy** — the SVGs are one-off inline paths per page. This design system's Button/Tag components accept an optional icon slot; when you need a new glyph, match this stroke weight and style (2px stroke, no fill, ~24x24 viewbox) or substitute from **Lucide** (closest CDN match, same stroke-outline aesthetic) and flag the substitution.

## Caveats

- **No logo/brand mark exists.** The site's `.brand-mark` CSS class is present but `display:none` — CamargAqua currently identifies itself with wordmark type only (`Camarg` + italic fuchsia `Aqua`). This design system does the same; it does not invent a logo.
- **All photography on the live site is hotlinked stock (Unsplash)**, explicitly flagged in the source repo's own README as "to be replaced by real photos." Only the two 3D building renders and the three team headshots are real CamargAqua assets, and those are the only images copied into `assets/`. Everything else in this design system's UI kit uses `<image-slot>` placeholders — swap in real product/site photography when available.
- **Fonts are loaded live from Google Fonts** (`tokens/fonts.css` `@import`) rather than self-hosted — this matches the live site's approach and needs no substitution (Barlow Condensed + DM Sans + JetBrains Mono are all genuine Google Fonts, exact match, not a substitution).
