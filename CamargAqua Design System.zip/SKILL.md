---
name: camargaqua-design
description: Use this skill to generate well-branded interfaces and assets for CamargAqua, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key things to remember about CamargAqua:
- French shrimp-aquaculture startup (RAS system, Port-Saint-Louis-du-Rhône, Camargue). Audience is investors/partners and future B2B buyers — copy is French, declarative, terroir-flavored, numbers-as-heroes.
- Palette: blush/rose is the *neutral* field (`--bg`), fuchsia (`--shrimp`) is the one accent, deep navy (`--royal`, `--royal-3`) is ink + dark-surface contrast. Never treat pink as decoration — it's the base.
- Type: Barlow Condensed (display, often weight 300 huge) + DM Sans (body) + JetBrains Mono (tiny tracked labels only).
- No logo exists — wordmark only ("Camarg" + italic fuchsia "Aqua"). Never invent a logo mark.
- No icon set exists — thin 1.5-2px stroke line icons, ad hoc SVGs, no icon font, no emoji.
